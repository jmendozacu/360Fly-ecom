<?php

class Idev_OneStepCheckout_Block_Deliverydate extends Mage_Core_Block_Template
{
}
